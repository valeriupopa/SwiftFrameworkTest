//
//  TestSwiftFramework.h
//  TestSwiftFramework
//
//  Created by Valeriu POPA on 10/4/18.
//  Copyright © 2018 Valeriu Popa. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TestSwiftFramework.
FOUNDATION_EXPORT double TestSwiftFrameworkVersionNumber;

//! Project version string for TestSwiftFramework.
FOUNDATION_EXPORT const unsigned char TestSwiftFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestSwiftFramework/PublicHeader.h>


